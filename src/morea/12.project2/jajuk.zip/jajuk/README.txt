This is the full Jajuk repository 

--- USING MAVEN ---

To build Jajuk (Maven2 is required, download it from http://maven.apache.org/)
, from the source folder containing the pom.xml file:           

$ mvn jar:jar

--- USING ANT ---

To compile Jajuk :
(Ant is required, download it on http://ant.apache.org/ )  
         
$ cd src/scripts
$ ant package_jar

----------------

-> jajuk.jar is built in target directory

All legals information are in the 'src/legals' directory
