
public class Movie {
	
	private String title, director;
	private int year, playingTime;
	
	public Movie(String t, String d, int y, int p) {
		title = t;
		director = d;
		year = y;
		playingTime = p;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getPlayingTime() {
		return playingTime;
	}

	public void setPlayingTime(int playingTime) {
		this.playingTime = playingTime;
	}
	
	public String toString() {
		return "\"" + title + "\", " + director + " (" +
				year + ")";
	}
	
}
