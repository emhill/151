import java.awt.Color;
import java.awt.Graphics;


public class Circle {

	private int x;
	private int y;
	private int radius;
	private Color color;
	private Color outlineColor;
	
	public Circle() {
		this(0, 0, 50, Color.blue);
	}
	
	public Circle(int x, int y, int r, Color c) {
		this(x, y, r, c, c);
	}
	
	public Circle(int x, int y, int r, Color c, Color oc) {
		this.x = x;
		this.y = y;
		radius = r;
		color = c;
		outlineColor = oc;
	}
	
	public void paint(Graphics page) {
		page.setColor(color);
		page.fillOval(x - radius, y - radius, 2 * radius, 2 * radius);
		page.setColor(outlineColor);
		page.drawOval(x - radius, y - radius, 2 * radius, 2 * radius);
	}
	
	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
		this.outlineColor = color;
	}
	
	public void setOutlineColor(Color c) {
		this.outlineColor = c;
	}
	
	public void setFillColor(Color c) {
		this.color = c;
	}
	
	public Color getFillColor() {
		return color;
	}
	

	
	public Color getOutlineColor() {
		return outlineColor;
	}

	public int getRadius() {
		return radius;
	}
	
	public void setRadius(int r) {
		this.radius = r;
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	public double getArea() {
		return Math.PI * radius * radius; // pi * r ** 2 in python
	}
	
	public double getPerimeter() {
		return 2 * Math.PI * radius;
	}

	public static void main(String[] args) {
		Circle c;
		c = new Circle(100, 100, 100, Color.MAGENTA);
		Circle d = new Circle();
		System.out.println("c: " + c.getRadius());
		System.out.println("d: " + d.getRadius());
		d.setRadius(200);
		System.out.println("d: " + d.getRadius());
		
		System.out.println("c area: " + c.getArea());
		System.out.println("d area: " + d.getArea());
		
		System.out.println("c perimeter: " + c.getPerimeter());
		System.out.println("d perimeter: " + d.getPerimeter());
	}

}
