import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Picture extends JPanel {
	
	private Circle circle;
	private Circle sun;
	private Square square;
	private Square square2;
	private Rectangle r;
	
	public Picture() {
		circle = new Circle(300, 300, 100, Color.MAGENTA);
		sun = new Circle(100, 100, 50, Color.green, Color.yellow);
		square = new Square();
		square2 = new Square(20, 30, 400, Color.blue);
		r = new Rectangle();
	}
	
	public void paintComponent(Graphics page) {
		r.paint(page);
		square2.paint(page);
		circle.paint(page);
		sun.paint(page);
		square.paint(page);
	}
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Picture");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		JPanel panel = new Picture();
		panel.setPreferredSize(new Dimension(500,500));
		
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}
