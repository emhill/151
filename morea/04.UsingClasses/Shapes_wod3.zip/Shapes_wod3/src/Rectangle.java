import java.awt.Color;
import java.awt.Graphics;


public class Rectangle {

	private int x, y, width, height;
	private Color color;
	
	public Rectangle() {
		this(10, 10, 100, 200, Color.red);
	}
	
	public Rectangle(int x, int y, int width, int height, Color c) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		color = c;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
	
	public void paint(Graphics page) {
		page.setColor(color);
		page.fillRect(x, y, width, height);
	}

}
