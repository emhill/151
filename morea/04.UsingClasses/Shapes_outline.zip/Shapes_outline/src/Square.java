import java.awt.Color;
import java.awt.Graphics;


public class Square {

	private int x, y, width;
	private Color color;
	
	public Square() {
		x = 0;
		y = 100;
		width = 50;
		color = Color.orange;
	}
	
	public Square(int x, int y, int w, Color c) {
		this.x = x;
		this.y = y;
		width = w;
		color = c;
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
	
	public int getArea() {
		return width * width;
	}
	
	public int getPerimeter() {
		return width * 4;
	}
	
	public void paint(Graphics page) {
		page.setColor(color);
		page.fillRect(x, y, width, width);
	}

	public static void main(String[] args) {
		Square s = new Square();
		System.out.println("Area: " + s.getArea());
		System.out.println("Perimenter: " + s.getPerimeter());
	}

}
